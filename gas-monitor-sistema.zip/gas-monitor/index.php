<?php
require_once __DIR__ . '/includes/auth.php';
exigirLogin();
$nomeUser = htmlspecialchars($_SESSION['user_nome'] ?? 'Utilizador');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Monitor de Gás Butano</title>

<!-- Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow:wght@300;500;700;900&display=swap" rel="stylesheet">

<style>
/* ═══════════════════════════════════════════════════
   RESET & ROOT
═══════════════════════════════════════════════════ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg:          #09090f;
  --bg2:         #111120;
  --bg3:         #1a1a2e;
  --border:      rgba(255,255,255,.07);
  --text:        #e8e8f0;
  --muted:       #6b6b8a;

  --cheio:       #00e5a0;
  --normal:      #f5c518;
  --baixo:       #ff8c00;
  --critico:     #ff2d55;

  --cheio-dim:   rgba(0,229,160,.12);
  --normal-dim:  rgba(245,197,24,.12);
  --baixo-dim:   rgba(255,140,0,.12);
  --critico-dim: rgba(255,45,85,.12);

  --font-display: 'Barlow', sans-serif;
  --font-mono:    'Share Tech Mono', monospace;
  --radius:       12px;
  --glow:         0 0 24px rgba(0,229,160,.25);
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--font-display);
  min-height: 100vh;
  overflow-x: hidden;
}

/* ═══════════════════════════════════════════════════
   BACKGROUND GRID
═══════════════════════════════════════════════════ */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image:
    linear-gradient(rgba(0,229,160,.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,229,160,.03) 1px, transparent 1px);
  background-size: 48px 48px;
  pointer-events: none;
  z-index: 0;
}

/* ═══════════════════════════════════════════════════
   LAYOUT
═══════════════════════════════════════════════════ */
.wrapper { position: relative; z-index: 1; max-width: 1440px; margin: 0 auto; padding: 24px 20px 60px; }

/* ─── HEADER ─── */
header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
  padding: 20px 32px;
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  margin-bottom: 28px;
}

.header-brand { display: flex; align-items: center; gap: 16px; }
.header-icon {
  width: 52px; height: 52px;
  background: var(--cheio-dim);
  border: 1px solid var(--cheio);
  border-radius: 14px;
  display: grid; place-items: center;
  font-size: 1.6rem;
}
.header-title h1 {
  font-size: 1.35rem;
  font-weight: 900;
  letter-spacing: .5px;
  text-transform: uppercase;
}
.header-title span {
  font-family: var(--font-mono);
  font-size: .72rem;
  color: var(--muted);
  letter-spacing: 2px;
}

.header-meta { display: flex; align-items: center; gap: 24px; }

.live-badge {
  display: flex; align-items: center; gap: 8px;
  font-family: var(--font-mono);
  font-size: .75rem;
  color: var(--cheio);
  letter-spacing: 1px;
}
.live-dot {
  width: 8px; height: 8px;
  border-radius: 50%;
  background: var(--cheio);
  animation: pulse-dot 1.4s ease-in-out infinite;
}
@keyframes pulse-dot {
  0%,100% { opacity:1; transform:scale(1); box-shadow:0 0 0 0 rgba(0,229,160,.5); }
  50%      { opacity:.7; transform:scale(1.3); box-shadow:0 0 0 6px rgba(0,229,160,0); }
}

#relogio {
  font-family: var(--font-mono);
  font-size: 1.1rem;
  color: var(--cheio);
  letter-spacing: 2px;
}

/* ─── STATS ROW ─── */
.stats-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 28px;
}
.stat-card {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 20px 24px;
  display: flex; flex-direction: column; gap: 6px;
  position: relative; overflow: hidden;
  transition: border-color .3s;
}
.stat-card::after {
  content: '';
  position: absolute; bottom: 0; left: 0; right: 0;
  height: 2px;
}
.stat-card.c-cheio   { border-color: rgba(0,229,160,.3); } .stat-card.c-cheio::after   { background: var(--cheio); }
.stat-card.c-normal  { border-color: rgba(245,197,24,.3); } .stat-card.c-normal::after  { background: var(--normal); }
.stat-card.c-baixo   { border-color: rgba(255,140,0,.3); } .stat-card.c-baixo::after   { background: var(--baixo); }
.stat-card.c-critico { border-color: rgba(255,45,85,.3);  } .stat-card.c-critico::after { background: var(--critico); }

.stat-label { font-size: .7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: var(--muted); }
.stat-value { font-size: 2rem; font-weight: 900; line-height: 1; }
.stat-sub   { font-family: var(--font-mono); font-size: .72rem; color: var(--muted); }

/* ─── GRID PRINCIPAL ─── */
.main-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 20px;
  margin-bottom: 28px;
}

/* ─── SENSOR CARD ─── */
.sensor-card {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 24px;
  display: flex; flex-direction: column; gap: 20px;
  position: relative;
  transition: transform .2s, box-shadow .2s;
}
.sensor-card:hover { transform: translateY(-2px); }

.sensor-card[data-estado="cheio"]   { --cor: var(--cheio);   --dim: var(--cheio-dim);   box-shadow: 0 0 0 1px rgba(0,229,160,.2); }
.sensor-card[data-estado="normal"]  { --cor: var(--normal);  --dim: var(--normal-dim);  box-shadow: 0 0 0 1px rgba(245,197,24,.2); }
.sensor-card[data-estado="baixo"]   { --cor: var(--baixo);   --dim: var(--baixo-dim);   box-shadow: 0 0 0 1px rgba(255,140,0,.2); }
.sensor-card[data-estado="critico"] { --cor: var(--critico); --dim: var(--critico-dim); box-shadow: 0 0 0 1px rgba(255,45,85,.2); animation: card-pulse 2s ease-in-out infinite; }

@keyframes card-pulse {
  0%,100% { box-shadow: 0 0 0 1px rgba(255,45,85,.3); }
  50%      { box-shadow: 0 0 12px 2px rgba(255,45,85,.4); }
}

.sensor-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
.sensor-name   { font-size: 1rem; font-weight: 700; }
.sensor-loc    { font-size: .72rem; color: var(--muted); margin-top: 3px; }
.sensor-badge  {
  font-family: var(--font-mono);
  font-size: .65rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: 1px;
  padding: 4px 10px; border-radius: 20px;
  background: var(--dim); color: var(--cor);
  border: 1px solid var(--cor);
  white-space: nowrap;
  flex-shrink: 0;
}

/* Cilindro de gás */
.gas-cylinder-wrap {
  display: flex; align-items: center; gap: 24px;
}
.cylinder {
  position: relative; flex-shrink: 0;
  width: 64px; height: 140px;
}
.cylinder-body {
  position: absolute; inset: 16px 0 0 0;
  border: 2px solid rgba(255,255,255,.15);
  border-radius: 18px;
  overflow: hidden;
  background: var(--bg3);
}
.cylinder-fill {
  position: absolute; bottom: 0; left: 0; right: 0;
  background: linear-gradient(to top, var(--cor), color-mix(in srgb, var(--cor) 60%, transparent));
  transition: height 1s cubic-bezier(.4,0,.2,1);
}
.cylinder-shine {
  position: absolute; top: 0; left: 8px; width: 6px; bottom: 0;
  background: linear-gradient(to bottom, rgba(255,255,255,.18), transparent);
  border-radius: 3px;
}
.cylinder-top {
  position: absolute; top: 4px; left: 50%; transform: translateX(-50%);
  width: 28px; height: 16px;
  background: rgba(255,255,255,.12);
  border: 2px solid rgba(255,255,255,.2);
  border-radius: 6px 6px 2px 2px;
}
.cylinder-valve {
  position: absolute; top: 0; left: 50%; transform: translateX(-50%);
  width: 12px; height: 8px;
  background: rgba(255,255,255,.2);
  border-radius: 3px 3px 0 0;
}

/* Métricas ao lado */
.cylinder-metrics { flex: 1; display: flex; flex-direction: column; gap: 12px; }
.metric { display: flex; flex-direction: column; gap: 3px; }
.metric-label { font-size: .65rem; text-transform: uppercase; letter-spacing: 1.5px; color: var(--muted); }
.metric-val   { font-size: 1.6rem; font-weight: 900; color: var(--cor); line-height: 1; }
.metric-unit  { font-family: var(--font-mono); font-size: .75rem; color: var(--muted); }

/* Barra de progresso */
.progress-wrap { display: flex; flex-direction: column; gap: 8px; }
.progress-labels { display: flex; justify-content: space-between; font-size: .7rem; }
.progress-bar {
  height: 8px;
  background: var(--bg3);
  border-radius: 4px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,.05);
}
.progress-fill {
  height: 100%;
  border-radius: 4px;
  background: linear-gradient(90deg, color-mix(in srgb, var(--cor) 60%, transparent), var(--cor));
  transition: width 1s cubic-bezier(.4,0,.2,1);
}

.sensor-footer {
  display: flex; align-items: center; justify-content: space-between;
  font-family: var(--font-mono); font-size: .68rem; color: var(--muted);
  border-top: 1px solid var(--border);
  padding-top: 12px;
}

/* Botão simular */
.btn-sim {
  font-family: var(--font-mono);
  font-size: .65rem;
  background: var(--bg3);
  border: 1px solid var(--border);
  color: var(--muted);
  padding: 4px 10px;
  border-radius: 6px;
  cursor: pointer;
  transition: border-color .2s, color .2s;
}
.btn-sim:hover { border-color: var(--cheio); color: var(--cheio); }

/* ─── PAINEL INFERIOR ─── */
.bottom-grid {
  display: grid;
  grid-template-columns: 1fr 380px;
  gap: 20px;
}
@media (max-width: 900px) { .bottom-grid { grid-template-columns: 1fr; } }

.panel {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
}
.panel-header {
  display: flex; align-items: center; gap: 10px;
  padding: 16px 24px;
  border-bottom: 1px solid var(--border);
  font-size: .7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: var(--muted);
}
.panel-icon { font-size: 1rem; }
.panel-body { padding: 20px 24px; }

/* Seletor de sensor */
.chart-controls {
  display: flex; gap: 10px; align-items: center;
  margin-bottom: 16px;
  flex-wrap: wrap;
}
.chart-controls select {
  font-family: var(--font-mono);
  font-size: .75rem;
  background: var(--bg3);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 6px 10px;
  border-radius: 6px;
  cursor: pointer;
}

/* Alertas */
.alerta-list { display: flex; flex-direction: column; gap: 8px; max-height: 340px; overflow-y: auto; }
.alerta-list::-webkit-scrollbar { width: 4px; }
.alerta-list::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

.alerta-item {
  display: flex; gap: 12px; align-items: flex-start;
  padding: 10px 14px;
  border-radius: 8px;
  border: 1px solid transparent;
  font-size: .78rem;
  animation: slide-in .35s ease;
}
@keyframes slide-in { from { opacity:0; transform:translateX(10px); } to { opacity:1; transform:none; } }

.alerta-item.critico { background: var(--critico-dim); border-color: rgba(255,45,85,.2);   color: var(--critico); }
.alerta-item.baixo   { background: var(--baixo-dim);   border-color: rgba(255,140,0,.2);   color: var(--baixo);   }
.alerta-item.normal  { background: var(--normal-dim);  border-color: rgba(245,197,24,.15); color: var(--normal);  }

.alerta-hora { font-family: var(--font-mono); font-size: .62rem; opacity: .7; white-space: nowrap; margin-top: 2px; }

/* Toast de notificação */
#toast-container {
  position: fixed; top: 20px; right: 20px;
  display: flex; flex-direction: column; gap: 10px;
  z-index: 9999;
}
.toast {
  display: flex; align-items: flex-start; gap: 12px;
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 14px 18px;
  max-width: 340px;
  animation: toast-in .35s cubic-bezier(.4,0,.2,1);
  box-shadow: 0 8px 32px rgba(0,0,0,.5);
}
.toast.critico { border-left: 4px solid var(--critico); }
.toast.baixo   { border-left: 4px solid var(--baixo); }
.toast.normal  { border-left: 4px solid var(--normal); }

@keyframes toast-in {
  from { opacity:0; transform:translateX(20px) scale(.95); }
  to   { opacity:1; transform:none; }
}
.toast-icon { font-size: 1.3rem; flex-shrink:0; margin-top: 1px; }
.toast-title { font-size: .78rem; font-weight: 700; margin-bottom: 3px; }
.toast-msg   { font-size: .72rem; color: var(--muted); line-height: 1.45; }
.toast-close {
  margin-left: auto; cursor: pointer;
  color: var(--muted); font-size: 1rem;
  background: none; border: none;
  flex-shrink: 0;
}

/* ─── EMPTY / LOADING ─── */
.loading {
  display: flex; align-items: center; justify-content: center;
  height: 120px; color: var(--muted);
  font-family: var(--font-mono); font-size: .8rem; gap: 10px;
}
.spinner {
  width: 20px; height: 20px;
  border: 2px solid var(--border);
  border-top-color: var(--cheio);
  border-radius: 50%;
  animation: spin .8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>

<div id="toast-container"></div>

<div class="wrapper">

  <!-- HEADER -->
  <header>
    <div class="header-brand">
      <div class="header-icon">⛽</div>
      <div class="header-title">
        <h1>Monitor de Gás Butano</h1>
        <span>Sistema Inteligente &bull; Tempo Real &bull; v2.0</span>
      </div>
    </div>
    <div class="header-meta">
      <div class="live-badge">
        <div class="live-dot"></div>
        LIGADO (SSE)
      </div>
      <div id="relogio">--:--:--</div>
      <div style="display:flex;align-items:center;gap:10px;padding-left:16px;border-left:1px solid rgba(255,255,255,.08)">
        <div style="font-family:var(--font-mono);font-size:.72rem;color:var(--muted)">👤 <?= $nomeUser ?></div>
        <a href="sair.php" style="font-family:var(--font-mono);font-size:.65rem;background:transparent;border:1px solid rgba(255,45,85,.35);color:#ff6b87;padding:5px 12px;border-radius:6px;text-decoration:none;white-space:nowrap" onmouseover="this.style.background='rgba(255,45,85,.12)'" onmouseout="this.style.background='transparent'">Sair</a>
      </div>
    </div>
  </header>

  <!-- STATS RÁPIDAS -->
  <div class="stats-row" id="stats-row">
    <div class="loading"><div class="spinner"></div> A carregar sensores…</div>
  </div>

  <!-- CARDS DOS SENSORES -->
  <div class="main-grid" id="main-grid"></div>

  <!-- GRÁFICO + ALERTAS -->
  <div class="bottom-grid">

    <!-- Gráfico histórico -->
    <div class="panel">
      <div class="panel-header">
        <span class="panel-icon">📈</span>
        Histórico de Nível
      </div>
      <div class="panel-body">
        <div class="chart-controls">
          <select id="chart-sensor">
            <option value="1">Botijão Cozinha</option>
            <option value="2">Botijão Garagem</option>
            <option value="3">Botijão Exterior</option>
          </select>
          <select id="chart-horas">
            <option value="6">Últimas 6 h</option>
            <option value="12">Últimas 12 h</option>
            <option value="24" selected>Últimas 24 h</option>
            <option value="72">Últimos 3 dias</option>
          </select>
        </div>
        <canvas id="chart-nivel" height="220"></canvas>
      </div>
    </div>

    <!-- Alertas -->
    <div class="panel">
      <div class="panel-header">
        <span class="panel-icon">🔔</span>
        Alertas Recentes
      </div>
      <div class="panel-body">
        <div class="alerta-list" id="alerta-list">
          <div class="loading"><div class="spinner"></div></div>
        </div>
      </div>
    </div>

  </div><!-- /bottom-grid -->
</div><!-- /wrapper -->

<script>
/* ============================================================
   RELÓGIO
============================================================ */
const elRelogio = document.getElementById('relogio');
function atualizarRelogio() {
  elRelogio.textContent = new Date().toLocaleTimeString('pt-PT');
}
atualizarRelogio();
setInterval(atualizarRelogio, 1000);

/* ============================================================
   UTILIDADES
============================================================ */
const ESTADOS = { critico:'🔴 CRÍTICO', baixo:'🟠 BAIXO', normal:'🟡 NORMAL', cheio:'🟢 CHEIO' };
const CORES    = { critico:'#ff2d55', baixo:'#ff8c00', normal:'#f5c518', cheio:'#00e5a0' };

function formatarHora(str) {
  if (!str) return '--';
  const d = new Date(str);
  return d.toLocaleTimeString('pt-PT', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
}

/* ============================================================
   SSE — Server-Sent Events
============================================================ */
let estadosAnteriores = {};
let graficoCriado = false;
let chartNivel = null;

const sse = new EventSource('api/leituras.php?action=stream');

sse.onmessage = (e) => {
  const sensores = JSON.parse(e.data);
  renderizarStats(sensores);
  renderizarCards(sensores);

  // Alertas toast quando estado muda
  sensores.forEach(s => {
    const sid   = s.sensor_id;
    const antes = estadosAnteriores[sid];
    if (antes && antes !== s.estado && s.estado !== 'cheio') {
      mostrarToast(s);
      carregarAlertas();
    }
    estadosAnteriores[sid] = s.estado;
  });

  if (!graficoCriado) {
    graficoCriado = true;
    carregarGrafico();
    carregarAlertas();
  }
};

sse.onerror = () => {
  console.warn('SSE desligado — a reconectar…');
};

/* ============================================================
   RENDER — STATS RÁPIDAS
============================================================ */
function renderizarStats(sensores) {
  const el = document.getElementById('stats-row');
  const totalSensores  = sensores.length;
  const criticos       = sensores.filter(s => s.estado === 'critico').length;
  const baixos         = sensores.filter(s => s.estado === 'baixo').length;
  const mediaKg        = (sensores.reduce((a,s) => a + s.nivel_kg, 0) / totalSensores).toFixed(1);
  const mediaPct       = Math.round(sensores.reduce((a,s) => a + s.nivel_pct, 0) / totalSensores);

  el.innerHTML = `
    <div class="stat-card c-${criticos > 0 ? 'critico' : 'cheio'}">
      <div class="stat-label">Sensores Ativos</div>
      <div class="stat-value">${totalSensores}</div>
      <div class="stat-sub">${criticos} crítico(s) · ${baixos} baixo(s)</div>
    </div>
    <div class="stat-card c-${mediaPct <= 15 ? 'critico' : mediaPct <= 30 ? 'baixo' : mediaPct <= 70 ? 'normal' : 'cheio'}">
      <div class="stat-label">Nível Médio</div>
      <div class="stat-value">${mediaPct}<span style="font-size:1rem">%</span></div>
      <div class="stat-sub">${mediaKg} kg em média por botijão</div>
    </div>
    <div class="stat-card c-${criticos > 0 ? 'critico' : 'cheio'}">
      <div class="stat-label">Alertas Ativos</div>
      <div class="stat-value">${criticos + baixos}</div>
      <div class="stat-sub">${criticos} crítico(s) · ${baixos} nível baixo</div>
    </div>
    <div class="stat-card c-cheio">
      <div class="stat-label">Botijão Capacidade</div>
      <div class="stat-value">13<span style="font-size:1rem">kg</span></div>
      <div class="stat-sub">Butano standard — GLP</div>
    </div>
  `;
}

/* ============================================================
   RENDER — CARDS DE SENSOR
============================================================ */
function renderizarCards(sensores) {
  const grid = document.getElementById('main-grid');

  sensores.forEach(s => {
    const id     = s.sensor_id;
    const pct    = s.nivel_pct.toFixed(1);
    const kg     = s.nivel_kg.toFixed(2);
    const temp   = s.temperatura ? s.temperatura + ' °C' : '—';
    const estado = s.estado;

    let card = document.getElementById(`sensor-${id}`);
    if (!card) {
      card = document.createElement('div');
      card.id = `sensor-${id}`;
      card.className = 'sensor-card';
      grid.appendChild(card);
    }
    card.dataset.estado = estado;

    card.innerHTML = `
      <div class="sensor-header">
        <div>
          <div class="sensor-name">${s.nome}</div>
          <div class="sensor-loc">📍 ${s.localizacao}</div>
        </div>
        <div class="sensor-badge">${ESTADOS[estado]}</div>
      </div>

      <div class="gas-cylinder-wrap">
        <div class="cylinder">
          <div class="cylinder-valve"></div>
          <div class="cylinder-top"></div>
          <div class="cylinder-body">
            <div class="cylinder-fill" style="height:${pct}%"></div>
            <div class="cylinder-shine"></div>
          </div>
        </div>
        <div class="cylinder-metrics">
          <div class="metric">
            <div class="metric-label">Nível</div>
            <div class="metric-val">${pct}<span class="metric-unit">%</span></div>
          </div>
          <div class="metric">
            <div class="metric-label">Restante</div>
            <div class="metric-val">${kg}<span class="metric-unit"> kg</span></div>
          </div>
          <div class="metric">
            <div class="metric-label">Temperatura</div>
            <div class="metric-val" style="font-size:1rem">${temp}</div>
          </div>
        </div>
      </div>

      <div class="progress-wrap">
        <div class="progress-labels">
          <span style="font-family:var(--font-mono);font-size:.68rem;color:var(--muted)">0%</span>
          <span style="font-family:var(--font-mono);font-size:.68rem;color:var(--cor)">${pct}%</span>
          <span style="font-family:var(--font-mono);font-size:.68rem;color:var(--muted)">100%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${pct}%"></div>
        </div>
      </div>

      <div class="sensor-footer">
        <span>⏱ Última leitura: ${formatarHora(s.lido_em)}</span>
        <button class="btn-sim" onclick="simularLeitura(${id})">▶ Simular</button>
      </div>
    `;
  });
}

/* ============================================================
   GRÁFICO HISTÓRICO
============================================================ */
async function carregarGrafico() {
  const sid   = document.getElementById('chart-sensor').value;
  const horas = document.getElementById('chart-horas').value;
  const res   = await fetch(`api/leituras.php?action=historico&sensor_id=${sid}&horas=${horas}`);
  const dados = await res.json();

  const labels = dados.map(d => {
    const dt = new Date(d.lido_em);
    return dt.toLocaleTimeString('pt-PT', { hour:'2-digit', minute:'2-digit' });
  });
  const niveis = dados.map(d => d.nivel_pct);

  const ctx = document.getElementById('chart-nivel').getContext('2d');
  if (chartNivel) chartNivel.destroy();

  // Gradiente
  const grad = ctx.createLinearGradient(0, 0, 0, 220);
  grad.addColorStop(0,   'rgba(0,229,160,.4)');
  grad.addColorStop(.7,  'rgba(0,229,160,.05)');
  grad.addColorStop(1,   'rgba(0,229,160,0)');

  chartNivel = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Nível (%)',
        data: niveis,
        borderColor: '#00e5a0',
        borderWidth: 2.5,
        fill: true,
        backgroundColor: grad,
        pointRadius: dados.length < 20 ? 4 : 0,
        pointBackgroundColor: '#00e5a0',
        tension: .4,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { ticks: { color:'#6b6b8a', font:{family:'Share Tech Mono',size:10} }, grid: { color:'rgba(255,255,255,.04)' } },
        y: {
          min: 0, max: 100,
          ticks: { color:'#6b6b8a', font:{family:'Share Tech Mono',size:10}, callback: v => v + '%' },
          grid: { color:'rgba(255,255,255,.04)' }
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1a1a2e',
          borderColor: 'rgba(0,229,160,.3)',
          borderWidth: 1,
          titleFont: { family:'Share Tech Mono' },
          bodyFont:  { family:'Share Tech Mono' },
          callbacks: {
            label: ctx => ` ${ctx.parsed.y.toFixed(1)} %`,
          }
        }
      },
      interaction: { intersect: false, mode: 'index' },
    }
  });
}

document.getElementById('chart-sensor').addEventListener('change', carregarGrafico);
document.getElementById('chart-horas').addEventListener('change', carregarGrafico);
// Atualizar gráfico a cada 30 s
setInterval(carregarGrafico, 30000);

/* ============================================================
   ALERTAS
============================================================ */
async function carregarAlertas() {
  const res    = await fetch('api/leituras.php?action=alertas');
  const alertas = await res.json();
  const el     = document.getElementById('alerta-list');

  if (!alertas.length) {
    el.innerHTML = '<div class="loading" style="height:60px">Sem alertas registados.</div>';
    return;
  }

  el.innerHTML = alertas.map(a => `
    <div class="alerta-item ${a.tipo}">
      <div style="flex:1">
        <div style="font-weight:700;margin-bottom:3px">${a.sensor_nome}</div>
        <div>${a.mensagem}</div>
        <div class="alerta-hora">${new Date(a.criado_em).toLocaleString('pt-PT')}</div>
      </div>
    </div>
  `).join('');
}

/* ============================================================
   TOAST
============================================================ */
function mostrarToast(sensor) {
  const icones  = { critico:'🔴', baixo:'🟠', normal:'🟡' };
  const titulos = { critico:'Nível Crítico!', baixo:'Nível Baixo', normal:'Nível Normal' };

  const toast = document.createElement('div');
  toast.className = `toast ${sensor.estado}`;
  toast.innerHTML = `
    <div class="toast-icon">${icones[sensor.estado] ?? 'ℹ️'}</div>
    <div>
      <div class="toast-title">${titulos[sensor.estado] ?? 'Alerta'} — ${sensor.nome}</div>
      <div class="toast-msg">${sensor.nivel_pct.toFixed(1)}% restante (${sensor.nivel_kg.toFixed(2)} kg)</div>
    </div>
    <button class="toast-close" onclick="this.closest('.toast').remove()">✕</button>
  `;
  document.getElementById('toast-container').prepend(toast);
  setTimeout(() => toast.remove(), 8000);
}

/* ============================================================
   SIMULAÇÃO (botão por card)
============================================================ */
async function simularLeitura(sensorId) {
  const nivel = Math.max(2, Math.random() * 100);
  await fetch(`api/leituras.php?action=simular&sensor_id=${sensorId}&nivel=${nivel.toFixed(1)}`);
}
</script>
</body>
</html>
