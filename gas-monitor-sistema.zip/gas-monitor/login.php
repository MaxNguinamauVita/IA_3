<?php
// ============================================================
//  login.php — Ecrã de Login e Cadastro
// ============================================================
require_once __DIR__ . '/includes/auth.php';

// Já autenticado → vai direto ao dashboard
if (autenticado()) {
    header('Location: index.php');
    exit;
}

$modo      = $_POST['modo']   ?? ($_GET['modo'] ?? 'login');   // 'login' | 'cadastro'
$erro      = '';
$sucesso   = '';
$email_val = htmlspecialchars($_POST['email'] ?? '');
$nome_val  = htmlspecialchars($_POST['nome']  ?? '');

// ── Processar formulário ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($modo === 'cadastro') {
        $res = cadastrar($_POST['nome'] ?? '', $_POST['email'] ?? '', $_POST['senha'] ?? '');
        if ($res['ok']) {
            $sucesso = $res['mensagem'];
            $modo    = 'login';  // volta para o login após cadastro
        } else {
            $erro = $res['erro'];
        }
    } else {
        $res = login($_POST['email'] ?? '', $_POST['senha'] ?? '');
        if ($res['ok']) {
            header('Location: index.php');
            exit;
        } else {
            $erro = $res['erro'];
        }
    }
}

$isLogin    = ($modo === 'login');
$tituloPag  = $isLogin ? 'Entrar' : 'Criar Conta';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>⛽ Monitor de Gás — <?= $tituloPag ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow:wght@300;500;700;900&display=swap" rel="stylesheet">
<style>
/* ═══ RESET ═══════════════════════════════════════════════ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg:       #09090f;
  --bg2:      #111120;
  --bg3:      #1a1a2e;
  --border:   rgba(255,255,255,.08);
  --text:     #e8e8f0;
  --muted:    #6b6b8a;
  --accent:   #00e5a0;
  --accent2:  #00b87a;
  --erro:     #ff2d55;
  --ok:       #00e5a0;
  --font-d:   'Barlow', sans-serif;
  --font-m:   'Share Tech Mono', monospace;
  --r:        14px;
}

body {
  min-height: 100vh;
  background: var(--bg);
  color: var(--text);
  font-family: var(--font-d);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
}

/* ─── fundo animado ─── */
.bg-grid {
  position: fixed; inset: 0; z-index: 0;
  background-image:
    linear-gradient(rgba(0,229,160,.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,229,160,.025) 1px, transparent 1px);
  background-size: 52px 52px;
  animation: grid-drift 60s linear infinite;
}
@keyframes grid-drift { to { background-position: 52px 52px; } }

.bg-glow {
  position: fixed; z-index: 0;
  border-radius: 50%;
  filter: blur(120px);
  pointer-events: none;
}
.bg-glow-1 {
  width: 600px; height: 600px;
  background: rgba(0,229,160,.07);
  top: -200px; right: -200px;
}
.bg-glow-2 {
  width: 400px; height: 400px;
  background: rgba(0,100,255,.05);
  bottom: -150px; left: -100px;
}

/* ─── card principal ─── */
.card {
  position: relative; z-index: 1;
  width: 100%; max-width: 440px;
  margin: 20px;
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 40px 40px 36px;
  box-shadow: 0 32px 80px rgba(0,0,0,.6);
  animation: card-in .5s cubic-bezier(.4,0,.2,1);
}
@keyframes card-in {
  from { opacity:0; transform: translateY(24px) scale(.97); }
  to   { opacity:1; transform: none; }
}

/* ─── logo / topo ─── */
.logo-wrap {
  display: flex; align-items: center; gap: 14px;
  margin-bottom: 32px;
}
.logo-icon {
  width: 52px; height: 52px;
  background: rgba(0,229,160,.1);
  border: 1px solid rgba(0,229,160,.3);
  border-radius: 14px;
  display: grid; place-items: center;
  font-size: 1.7rem;
  flex-shrink: 0;
}
.logo-text h1 {
  font-size: 1.1rem; font-weight: 900;
  text-transform: uppercase; letter-spacing: .5px;
}
.logo-text p {
  font-family: var(--font-m);
  font-size: .65rem; color: var(--muted);
  letter-spacing: 2px; margin-top: 3px;
}

/* ─── tabs login/cadastro ─── */
.tabs {
  display: grid; grid-template-columns: 1fr 1fr;
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 4px; gap: 4px;
  margin-bottom: 28px;
}
.tab-btn {
  padding: 9px;
  border: none; border-radius: 7px;
  font-family: var(--font-d);
  font-size: .82rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: .5px;
  cursor: pointer;
  transition: background .2s, color .2s, box-shadow .2s;
  text-decoration: none;
  display: block; text-align: center;
}
.tab-btn.ativo {
  background: var(--accent);
  color: #000;
  box-shadow: 0 2px 12px rgba(0,229,160,.35);
}
.tab-btn:not(.ativo) {
  background: transparent;
  color: var(--muted);
}
.tab-btn:not(.ativo):hover { color: var(--text); }

/* ─── formulário ─── */
.form-group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
.form-group label {
  font-size: .7rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: 1.5px;
  color: var(--muted);
}
.form-group input {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 13px 16px;
  color: var(--text);
  font-family: var(--font-d);
  font-size: .95rem;
  transition: border-color .2s, box-shadow .2s;
  outline: none;
  width: 100%;
}
.form-group input::placeholder { color: var(--muted); }
.form-group input:focus {
  border-color: rgba(0,229,160,.5);
  box-shadow: 0 0 0 3px rgba(0,229,160,.08);
}

/* ─── senha com olho ─── */
.input-senha-wrap { position: relative; }
.input-senha-wrap input { padding-right: 44px; }
.btn-olho {
  position: absolute; right: 14px; top: 50%; transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: var(--muted); font-size: 1rem;
  transition: color .2s; line-height: 1;
}
.btn-olho:hover { color: var(--accent); }

/* ─── botão principal ─── */
.btn-principal {
  width: 100%;
  padding: 14px;
  border: none; border-radius: 10px;
  background: var(--accent);
  color: #000;
  font-family: var(--font-d);
  font-size: .95rem; font-weight: 900;
  text-transform: uppercase; letter-spacing: 1px;
  cursor: pointer;
  transition: background .2s, transform .15s, box-shadow .2s;
  box-shadow: 0 4px 20px rgba(0,229,160,.3);
  margin-top: 8px;
}
.btn-principal:hover {
  background: var(--accent2);
  transform: translateY(-1px);
  box-shadow: 0 6px 28px rgba(0,229,160,.45);
}
.btn-principal:active { transform: translateY(0); }

/* ─── mensagens ─── */
.msg {
  border-radius: 10px;
  padding: 12px 16px;
  font-size: .82rem;
  margin-bottom: 18px;
  border: 1px solid transparent;
  display: flex; align-items: flex-start; gap: 10px;
  animation: msg-in .3s ease;
}
@keyframes msg-in { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:none; } }
.msg-erro  { background: rgba(255,45,85,.1);  border-color: rgba(255,45,85,.25);  color: #ff6b87; }
.msg-ok    { background: rgba(0,229,160,.1);  border-color: rgba(0,229,160,.25);  color: var(--accent); }
.msg-icon  { flex-shrink: 0; font-size: 1rem; margin-top: 1px; }

/* ─── divisor / sugestão ─── */
.divisor {
  display: flex; align-items: center; gap: 12px;
  margin: 22px 0 18px;
  color: var(--muted);
  font-size: .72rem;
  font-family: var(--font-m);
  letter-spacing: 1px;
}
.divisor::before, .divisor::after {
  content: ''; flex: 1;
  height: 1px; background: var(--border);
}

/* ─── sugestão contextual ─── */
.sugestao {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 14px 16px;
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
}
.sugestao-text { font-size: .8rem; color: var(--muted); line-height: 1.5; }
.sugestao-text strong { color: var(--text); display: block; margin-bottom: 2px; }
.btn-sugestao {
  flex-shrink: 0;
  background: transparent;
  border: 1px solid rgba(0,229,160,.4);
  border-radius: 8px;
  color: var(--accent);
  font-family: var(--font-d);
  font-size: .75rem; font-weight: 700;
  padding: 7px 14px;
  cursor: pointer;
  text-decoration: none;
  white-space: nowrap;
  transition: background .2s, border-color .2s;
}
.btn-sugestao:hover {
  background: rgba(0,229,160,.1);
  border-color: var(--accent);
}

/* ─── rodapé ─── */
.card-footer {
  margin-top: 24px;
  text-align: center;
  font-family: var(--font-m);
  font-size: .65rem;
  color: var(--muted);
  letter-spacing: .5px;
}
.live-dot {
  display: inline-block; width: 6px; height: 6px;
  border-radius: 50%; background: var(--accent);
  animation: pulse .2s ease-in-out infinite;
  margin-right: 6px; vertical-align: middle;
}
@keyframes pulse {
  0%,100% { opacity:1; } 50% { opacity:.4; }
}

/* ─── transição de modo ─── */
.form-fields { animation: fade-in .3s ease; }
@keyframes fade-in { from { opacity:0; } to { opacity:1; } }
</style>
</head>
<body>

<div class="bg-grid"></div>
<div class="bg-glow bg-glow-1"></div>
<div class="bg-glow bg-glow-2"></div>

<div class="card">

  <!-- Logo -->
  <div class="logo-wrap">
    <div class="logo-icon">⛽</div>
    <div class="logo-text">
      <h1>Monitor de Gás</h1>
      <p>SISTEMA INTELIGENTE · BUTANO</p>
    </div>
  </div>

  <!-- Tabs login / cadastro -->
  <div class="tabs">
    <a href="login.php?modo=login"
       class="tab-btn <?= $isLogin ? 'ativo' : '' ?>">
      Entrar
    </a>
    <a href="login.php?modo=cadastro"
       class="tab-btn <?= !$isLogin ? 'ativo' : '' ?>">
      Cadastrar
    </a>
  </div>

  <!-- Mensagens de feedback -->
  <?php if ($erro): ?>
    <div class="msg msg-erro">
      <span class="msg-icon">⚠️</span>
      <span><?= htmlspecialchars($erro) ?></span>
    </div>
  <?php endif; ?>
  <?php if ($sucesso): ?>
    <div class="msg msg-ok">
      <span class="msg-icon">✅</span>
      <span><?= htmlspecialchars($sucesso) ?></span>
    </div>
  <?php endif; ?>

  <!-- Formulário -->
  <form method="POST" action="login.php?modo=<?= $isLogin ? 'login' : 'cadastro' ?>" class="form-fields">
    <input type="hidden" name="modo" value="<?= $isLogin ? 'login' : 'cadastro' ?>">

    <?php if (!$isLogin): ?>
    <div class="form-group">
      <label for="nome">Nome completo</label>
      <input
        type="text" id="nome" name="nome"
        placeholder="O seu nome"
        value="<?= $nome_val ?>"
        autocomplete="name"
        required
      >
    </div>
    <?php endif; ?>

    <div class="form-group">
      <label for="email">E-mail</label>
      <input
        type="email" id="email" name="email"
        placeholder="exemplo@email.com"
        value="<?= $email_val ?>"
        autocomplete="email"
        required
      >
    </div>

    <div class="form-group">
      <label for="senha">Senha</label>
      <div class="input-senha-wrap">
        <input
          type="password" id="senha" name="senha"
          placeholder="<?= $isLogin ? 'A sua senha' : 'Mínimo 6 caracteres' ?>"
          autocomplete="<?= $isLogin ? 'current-password' : 'new-password' ?>"
          required
        >
        <button type="button" class="btn-olho" onclick="toggleSenha(this)" title="Mostrar/ocultar senha">
          👁
        </button>
      </div>
    </div>

    <button type="submit" class="btn-principal">
      <?= $isLogin ? '→ Entrar no Sistema' : '+ Criar Minha Conta' ?>
    </button>
  </form>

  <!-- Divisor -->
  <div class="divisor">ou</div>

  <!-- Sugestão contextual -->
  <?php if ($isLogin): ?>
  <div class="sugestao">
    <div class="sugestao-text">
      <strong>Ainda não tem conta?</strong>
      Cadastre-se gratuitamente e comece a monitorizar.
    </div>
    <a href="login.php?modo=cadastro" class="btn-sugestao">Cadastrar</a>
  </div>
  <?php else: ?>
  <div class="sugestao">
    <div class="sugestao-text">
      <strong>Já tem uma conta?</strong>
      Faça login com as suas credenciais.
    </div>
    <a href="login.php?modo=login" class="btn-sugestao">Entrar</a>
  </div>
  <?php endif; ?>

  <!-- Rodapé -->
  <div class="card-footer">
    <span class="live-dot"></span>
    Sistema ativo · v2.0 · PHP + MySQL
  </div>

</div><!-- /card -->

<script>
function toggleSenha(btn) {
  const inp = btn.previousElementSibling;
  const vis = inp.type === 'text';
  inp.type   = vis ? 'password' : 'text';
  btn.textContent = vis ? '👁' : '🙈';
}
</script>
</body>
</html>
