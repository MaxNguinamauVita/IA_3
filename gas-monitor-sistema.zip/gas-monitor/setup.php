#!/usr/bin/env php
<?php
// ============================================================
//  setup.php — Instalador de linha de comandos
//  Uso: php setup.php
// ============================================================

echo "\n";
echo "╔══════════════════════════════════════════════════════╗\n";
echo "║   Monitor de Gás Butano — Instalador               ║\n";
echo "╚══════════════════════════════════════════════════════╝\n\n";

// Valores padrão
$host = prompt("Host MySQL",     'localhost');
$user = prompt("Utilizador",     'root');
$pass = prompt("Password",       '', true);
$db   = prompt("Base de dados",  'gas_monitor');

echo "\n→ A ligar ao MySQL…\n";
try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    die("❌ Erro: " . $e->getMessage() . "\n");
}

echo "→ A criar base de dados e tabelas…\n";
$sql = file_get_contents(__DIR__ . '/schema.sql');
foreach (explode(';', $sql) as $stmt) {
    $stmt = trim($stmt);
    if ($stmt) {
        try { $pdo->exec($stmt); } catch (PDOException $e) {
            // Ignora erros de INSERT duplicado em sensores
            if (!str_contains($e->getMessage(), 'Duplicate')) {
                echo "  ⚠ " . $e->getMessage() . "\n";
            }
        }
    }
}

echo "→ A gerar includes/config.php…\n";
$config = <<<PHP
<?php
define('DB_HOST',    '$host');
define('DB_NAME',    '$db');
define('DB_USER',    '$user');
define('DB_PASS',    '$pass');
define('DB_CHARSET', 'utf8mb4');

define('NIVEL_CRITICO', 15);
define('NIVEL_BAIXO',   30);
define('NIVEL_NORMAL',  70);
define('CAPACIDADE_KG', 13.0);

define('NTFY_TOPIC',  'gas-monitor-' . substr(md5(uniqid()), 0, 8));
define('NTFY_SERVER', 'https://ntfy.sh');
define('EMAIL_ALERTA', 'admin@exemplo.pt');
define('EMAIL_NOME',   'Sistema de Gás');
define('SSE_INTERVALO', 3);

function db(): PDO {
    static \$pdo = null;
    if (\$pdo === null) {
        \$dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
        \$pdo = new PDO(\$dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return \$pdo;
}
PHP;

file_put_contents(__DIR__ . '/includes/config.php', $config);

echo "\n✅ Instalação concluída!\n";
echo "   Abra no browser: http://localhost/<pasta-do-projeto>/\n\n";

// ─── helper ────────────────────────────────────────────────
function prompt(string $label, string $default = '', bool $secret = false): string {
    $hint = $default !== '' ? " [$default]" : '';
    echo "$label$hint: ";
    if ($secret && PHP_OS_FAMILY !== 'Windows') {
        system('stty -echo');
        $v = trim(fgets(STDIN));
        system('stty echo');
        echo "\n";
    } else {
        $v = trim(fgets(STDIN));
    }
    return $v !== '' ? $v : $default;
}
