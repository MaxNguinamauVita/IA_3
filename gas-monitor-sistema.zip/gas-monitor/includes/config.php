<?php
// ============================================================
//  config.php — Configuração Central do Sistema
// ============================================================

define('DB_HOST',     'localhost');
define('DB_NAME',     'gas_monitor');
define('DB_USER',     'root');
define('DB_PASS',     '');   // Sem senha — padrão XAMPP/WAMP/LAMP local
define('DB_CHARSET',  'utf8mb4');

// Limites de alerta (percentagem do depósito)
define('NIVEL_CRITICO',  15);   // ≤ 15 % → Crítico (vermelho)
define('NIVEL_BAIXO',    30);   // ≤ 30 % → Baixo (laranja)
define('NIVEL_NORMAL',   70);   // ≤ 70 % → Normal (amarelo)
// > 70 % → Cheio (verde)

// Capacidade do botijão em kg
define('CAPACIDADE_KG', 13.0);

// Configuração de notificações push (Ntfy.sh — gratuito, sem chave)
define('NTFY_TOPIC',   'gas-monitor-demo-pt');   // mude para um tópico único seu
define('NTFY_SERVER',  'https://ntfy.sh');

// Email de notificação (usa mail() nativo)
define('EMAIL_ALERTA', 'admin@exemplo.pt');
define('EMAIL_NOME',   'Sistema de Gás');

// Intervalo de polling SSE em segundos
define('SSE_INTERVALO', 3);

// ============================================================
//  Ligação PDO — reutilizável em todos os ficheiros
// ============================================================
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}
