<?php
// ============================================================
//  includes/auth.php — Autenticação (login + cadastro)
// ============================================================
require_once __DIR__ . '/config.php';

session_start();

// ── Já está autenticado? ───────────────────────────────────
function autenticado(): bool {
    return isset($_SESSION['user_id']);
}

// ── Redireciona para login se não autenticado ──────────────
function exigirLogin(): void {
    if (!autenticado()) {
        header('Location: login.php');
        exit;
    }
}

// ── Cadastrar novo utilizador ──────────────────────────────
function cadastrar(string $nome, string $email, string $senha): array {
    $nome  = trim($nome);
    $email = trim(strtolower($email));

    if (strlen($nome) < 2)
        return ['ok' => false, 'erro' => 'O nome deve ter pelo menos 2 caracteres.'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        return ['ok' => false, 'erro' => 'E-mail inválido.'];

    if (strlen($senha) < 6)
        return ['ok' => false, 'erro' => 'A senha deve ter pelo menos 6 caracteres.'];

    try {
        $pdo = db();
        // Verificar duplicado
        $chk = $pdo->prepare('SELECT id FROM utilizadores WHERE email = ?');
        $chk->execute([$email]);
        if ($chk->fetch())
            return ['ok' => false, 'erro' => 'Este e-mail já está registado. Faça login.'];

        $hash = password_hash($senha, PASSWORD_BCRYPT);
        $ins  = $pdo->prepare('INSERT INTO utilizadores (nome, email, senha_hash) VALUES (?, ?, ?)');
        $ins->execute([$nome, $email, $hash]);

        return ['ok' => true, 'mensagem' => 'Conta criada com sucesso! Pode iniciar sessão.'];
    } catch (PDOException $e) {
        return ['ok' => false, 'erro' => 'Erro interno: ' . $e->getMessage()];
    }
}

// ── Fazer login ────────────────────────────────────────────
function login(string $email, string $senha): array {
    $email = trim(strtolower($email));

    if (!$email || !$senha)
        return ['ok' => false, 'erro' => 'Preencha todos os campos.'];

    try {
        $stmt = db()->prepare('SELECT * FROM utilizadores WHERE email = ? AND ativo = 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($senha, $user['senha_hash']))
            return ['ok' => false, 'erro' => 'E-mail ou senha incorretos.'];

        // Iniciar sessão
        session_regenerate_id(true);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_nome'] = $user['nome'];
        $_SESSION['user_email'] = $user['email'];

        return ['ok' => true];
    } catch (PDOException $e) {
        return ['ok' => false, 'erro' => 'Erro interno: ' . $e->getMessage()];
    }
}

// ── Terminar sessão ────────────────────────────────────────
function logout(): void {
    session_destroy();
    header('Location: login.php');
    exit;
}
