<?php
// ============================================================
//  api/leituras.php — API REST + SSE para leituras em tempo real
// ============================================================
require_once __DIR__ . '/../includes/config.php';

$action = $_GET['action'] ?? 'status';

// ----------------------------------------------------------
//  GET /api/leituras.php?action=stream  → SSE em tempo real
// ----------------------------------------------------------
if ($action === 'stream') {
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');   // Nginx
    header('Connection: keep-alive');

    set_time_limit(0);
    ob_implicit_flush(true);

    $ultimo_alerta = [];  // evita re-notificar no mesmo ciclo

    while (true) {
        $dados = obterStatusTodos();
        echo "data: " . json_encode($dados) . "\n\n";
        flush();

        // Verificar e registar alertas novos
        foreach ($dados as $sensor) {
            $sid  = $sensor['sensor_id'];
            $tipo = $sensor['estado'];
            if (($ultimo_alerta[$sid] ?? '') !== $tipo) {
                registarAlerta($sensor);
                $ultimo_alerta[$sid] = $tipo;
            }
        }

        sleep(SSE_INTERVALO);
    }
}

// ----------------------------------------------------------
//  POST /api/leituras.php?action=registar  → nova leitura
// ----------------------------------------------------------
if ($action === 'registar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    $sensor_id  = (int)   ($input['sensor_id']   ?? 0);
    $nivel_pct  = (float) ($input['nivel_pct']   ?? 0);
    $temperatura = isset($input['temperatura']) ? (float)$input['temperatura'] : null;
    $pressao     = isset($input['pressao_kpa'])  ? (float)$input['pressao_kpa']  : null;

    if ($sensor_id <= 0 || $nivel_pct < 0 || $nivel_pct > 100) {
        http_response_code(422);
        echo json_encode(['erro' => 'Dados inválidos']);
        exit;
    }

    $nivel_kg = round(($nivel_pct / 100) * CAPACIDADE_KG, 3);

    try {
        $pdo = db();
        $stmt = $pdo->prepare("
            INSERT INTO leituras (sensor_id, nivel_pct, nivel_kg, temperatura, pressao_kpa)
            VALUES (:sid, :pct, :kg, :temp, :pres)
        ");
        $stmt->execute([
            ':sid'  => $sensor_id,
            ':pct'  => $nivel_pct,
            ':kg'   => $nivel_kg,
            ':temp' => $temperatura,
            ':pres' => $pressao,
        ]);
        echo json_encode(['ok' => true, 'nivel_kg' => $nivel_kg]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => $e->getMessage()]);
    }
    exit;
}

// ----------------------------------------------------------
//  GET /api/leituras.php?action=historico&sensor_id=1
// ----------------------------------------------------------
if ($action === 'historico') {
    header('Content-Type: application/json');
    $sid    = (int)($_GET['sensor_id'] ?? 1);
    $horas  = (int)($_GET['horas']    ?? 24);

    $stmt = db()->prepare("
        SELECT nivel_pct, nivel_kg, temperatura, lido_em
        FROM   leituras
        WHERE  sensor_id = :sid
          AND  lido_em  >= DATE_SUB(NOW(), INTERVAL :h HOUR)
        ORDER  BY lido_em ASC
        LIMIT  200
    ");
    $stmt->execute([':sid' => $sid, ':h' => $horas]);
    echo json_encode($stmt->fetchAll());
    exit;
}

// ----------------------------------------------------------
//  GET /api/leituras.php?action=alertas
// ----------------------------------------------------------
if ($action === 'alertas') {
    header('Content-Type: application/json');
    $stmt = db()->query("
        SELECT a.*, s.nome AS sensor_nome
        FROM   alertas a
        JOIN   sensores s ON s.id = a.sensor_id
        ORDER  BY a.criado_em DESC
        LIMIT  50
    ");
    echo json_encode($stmt->fetchAll());
    exit;
}

// ----------------------------------------------------------
//  GET /api/leituras.php?action=simular  → injeta leitura demo
// ----------------------------------------------------------
if ($action === 'simular') {
    header('Content-Type: application/json');
    $sid      = (int)($_GET['sensor_id'] ?? 1);
    $nivel    = (float)($_GET['nivel']   ?? rand(5, 95));
    $nivel_kg = round(($nivel / 100) * CAPACIDADE_KG, 3);

    $stmt = db()->prepare("
        INSERT INTO leituras (sensor_id, nivel_pct, nivel_kg, temperatura)
        VALUES (:sid, :pct, :kg, :temp)
    ");
    $stmt->execute([
        ':sid'  => $sid,
        ':pct'  => $nivel,
        ':kg'   => $nivel_kg,
        ':temp' => round(18 + rand(0, 60) / 10, 1),
    ]);
    echo json_encode(['ok' => true, 'nivel_pct' => $nivel, 'nivel_kg' => $nivel_kg]);
    exit;
}

// ----------------------------------------------------------
//  GET /api/leituras.php?action=status  → resumo de todos
// ----------------------------------------------------------
header('Content-Type: application/json');
echo json_encode(obterStatusTodos());

// ============================================================
//  Funções auxiliares
// ============================================================

function obterStatusTodos(): array {
    $stmt = db()->query("
        SELECT
            s.id   AS sensor_id,
            s.nome,
            s.localizacao,
            l.nivel_pct,
            l.nivel_kg,
            l.temperatura,
            l.pressao_kpa,
            l.lido_em
        FROM sensores s
        JOIN leituras  l ON l.id = (
            SELECT id FROM leituras
            WHERE sensor_id = s.id
            ORDER BY lido_em DESC LIMIT 1
        )
        WHERE s.ativo = 1
        ORDER BY s.id
    ");
    $rows = $stmt->fetchAll();

    foreach ($rows as &$r) {
        $r['estado']    = calcularEstado((float)$r['nivel_pct']);
        $r['nivel_pct'] = (float) $r['nivel_pct'];
        $r['nivel_kg']  = (float) $r['nivel_kg'];
    }
    return $rows;
}

function calcularEstado(float $pct): string {
    if ($pct <= NIVEL_CRITICO) return 'critico';
    if ($pct <= NIVEL_BAIXO)   return 'baixo';
    if ($pct <= NIVEL_NORMAL)  return 'normal';
    return 'cheio';
}

function registarAlerta(array $sensor): void {
    $estado = $sensor['estado'];
    if ($estado === 'cheio') return;   // sem alerta para cheio

    $msgs = [
        'critico' => "⛽ NÍVEL CRÍTICO! O botijão "{$sensor['nome']}" está a {$sensor['nivel_pct']}% ({$sensor['nivel_kg']} kg). Reponha imediatamente!",
        'baixo'   => "⚠️ Nível baixo. O botijão "{$sensor['nome']}" está a {$sensor['nivel_pct']}% ({$sensor['nivel_kg']} kg). Considere reabastecer.",
        'normal'  => "ℹ️ O botijão "{$sensor['nome']}" voltou ao nível normal ({$sensor['nivel_pct']}%).",
    ];

    $mensagem = $msgs[$estado] ?? "Estado: $estado";

    try {
        $stmt = db()->prepare("
            INSERT INTO alertas (sensor_id, tipo, mensagem, nivel_pct)
            VALUES (:sid, :tipo, :msg, :pct)
        ");
        $stmt->execute([
            ':sid'  => $sensor['sensor_id'],
            ':tipo' => $estado,
            ':msg'  => $mensagem,
            ':pct'  => $sensor['nivel_pct'],
        ]);
        $alertaId = db()->lastInsertId();

        // Notificação push via ntfy.sh (sem chave API, gratuito)
        enviarNotificacaoPush($mensagem, $estado);

        // Marcar como notificado
        db()->prepare("UPDATE alertas SET notificado=1 WHERE id=?")
             ->execute([$alertaId]);

    } catch (PDOException $e) {
        error_log('Erro ao registar alerta: ' . $e->getMessage());
    }
}

function enviarNotificacaoPush(string $mensagem, string $tipo): void {
    $prioridade = match($tipo) {
        'critico' => 'urgent',
        'baixo'   => 'high',
        default   => 'default',
    };
    $emoji = match($tipo) {
        'critico' => '🔴',
        'baixo'   => '🟠',
        default   => '🟡',
    };

    $contexto = stream_context_create([
        'http' => [
            'method'  => 'POST',
            'header'  => implode("\r\n", [
                'Content-Type: text/plain; charset=utf-8',
                'Title: Monitor de Gás Butano',
                "Priority: $prioridade",
                "Tags: $emoji,gas",
            ]),
            'content' => $mensagem,
            'timeout' => 5,
            'ignore_errors' => true,
        ]
    ]);

    @file_get_contents(NTFY_SERVER . '/' . NTFY_TOPIC, false, $contexto);
}
