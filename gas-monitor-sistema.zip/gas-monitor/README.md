# ⛽ Monitor de Gás Butano — Sistema Inteligente em Tempo Real

Sistema completo de monitorização do nível de gás butano com notificações push, dashboard em tempo real via SSE e histórico gráfico.

---

## 🗂 Estrutura do Projeto

```
gas-monitor/
├── index.php                  ← Dashboard principal (UI)
├── setup.php                  ← Instalador interativo (CLI)
├── schema.sql                 ← Esquema completo da BD + dados de demo
├── api/
│   └── leituras.php           ← API REST + stream SSE
└── includes/
    └── config.php             ← Configuração central (BD, limites, ntfy)
```

---

## ⚙️ Requisitos

| Componente  | Versão mínima |
|-------------|---------------|
| PHP         | 8.1           |
| MySQL       | 5.7 / MariaDB 10.4 |
| Extensões   | `pdo_mysql`, `curl` |
| Servidor    | Apache / Nginx (qualquer) |

---

## 🚀 Instalação Rápida

### Opção A — Instalador automático (recomendado)
```bash
cd /var/www/html/gas-monitor
php setup.php
```
O script cria a base de dados, as tabelas e gera o `config.php` automaticamente.

### Opção B — Manual
```bash
# 1. Importar esquema
mysql -u root -p < schema.sql

# 2. Editar credenciais
nano includes/config.php

# 3. Abrir no browser
http://localhost/gas-monitor/
```

---

## 📡 API Endpoints

| Método | URL | Descrição |
|--------|-----|-----------|
| GET | `api/leituras.php?action=stream` | **SSE** — stream em tempo real |
| GET | `api/leituras.php?action=status` | JSON — resumo de todos os sensores |
| GET | `api/leituras.php?action=historico&sensor_id=1&horas=24` | JSON — histórico |
| GET | `api/leituras.php?action=alertas` | JSON — últimos 50 alertas |
| GET | `api/leituras.php?action=simular&sensor_id=1&nivel=25` | Injetar leitura de teste |
| POST | `api/leituras.php?action=registar` | Registar leitura de sensor real |

### Exemplo POST (sensor físico / Arduino / ESP32):
```bash
curl -X POST http://localhost/gas-monitor/api/leituras.php?action=registar \
  -H "Content-Type: application/json" \
  -d '{"sensor_id":1,"nivel_pct":42.5,"temperatura":21.3}'
```

---

## 🔔 Notificações Push (ntfy.sh)

O sistema usa o serviço **gratuito** [ntfy.sh](https://ntfy.sh) — sem registo nem chave API.

1. Edite `NTFY_TOPIC` em `includes/config.php` para um nome único (ex.: `gas-minha-casa-2024`)
2. Instale a app **ntfy** no telemóvel (Android/iOS)
3. Subscreva o seu tópico — receberá alertas instantâneos

---

## 📊 Níveis de Alerta

| Estado   | Intervalo | Cor      | Ação Recomendada          |
|----------|-----------|----------|---------------------------|
| 🟢 Cheio  | > 70 %    | Verde    | Nenhuma                   |
| 🟡 Normal | 31–70 %   | Amarelo  | Vigiar                    |
| 🟠 Baixo  | 16–30 %   | Laranja  | Encomendar botijão novo   |
| 🔴 Crítico| ≤ 15 %    | Vermelho | Repor **imediatamente**   |

Os limites são configuráveis em `includes/config.php`.

---

## 🔌 Integração com Hardware

### ESP32 / Arduino (exemplo simplificado)
```cpp
// Enviar leitura a cada 60 segundos
float nivelPct = lerSensor();  // ex.: via HX711 + célula de carga
String payload = "{\"sensor_id\":1,\"nivel_pct\":" + String(nivelPct, 1) + "}";
// POST para: http://<ip-servidor>/gas-monitor/api/leituras.php?action=registar
```

### Sensor sugerido
- **Célula de carga 20 kg + HX711** — pesa o botijão e calcula percentagem
- **MQ-2 / MQ-6** — deteção de gás (segurança complementar)

---

## 🔧 Personalização

| Parâmetro | Ficheiro | Descrição |
|-----------|----------|-----------|
| `NIVEL_CRITICO` | `config.php` | Percentagem para alerta crítico (padrão: 15) |
| `NIVEL_BAIXO`   | `config.php` | Percentagem para alerta baixo (padrão: 30) |
| `CAPACIDADE_KG` | `config.php` | Capacidade do botijão em kg (padrão: 13.0) |
| `SSE_INTERVALO` | `config.php` | Frequência de actualização em segundos (padrão: 3) |
| `NTFY_TOPIC`    | `config.php` | Tópico único para notificações push |

---

## 📄 Licença
MIT — uso livre para projetos pessoais e comerciais.
