-- ============================================================
--  schema.sql — Esquema da Base de Dados
--  Executar UMA VEZ:  mysql -u root < schema.sql   (sem senha)
-- ============================================================

CREATE DATABASE IF NOT EXISTS gas_monitor
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE gas_monitor;

-- Utilizadores do sistema (login / cadastro)
CREATE TABLE IF NOT EXISTS utilizadores (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome         VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL UNIQUE,
    senha_hash   VARCHAR(255) NOT NULL,
    ativo        TINYINT(1)   NOT NULL DEFAULT 1,
    criado_em    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Sensores registados
CREATE TABLE IF NOT EXISTS sensores (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome         VARCHAR(80)  NOT NULL,
    localizacao  VARCHAR(120) NOT NULL DEFAULT '',
    ativo        TINYINT(1)   NOT NULL DEFAULT 1,
    criado_em    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Leituras do sensor (simuladas ou reais via API)
CREATE TABLE IF NOT EXISTS leituras (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sensor_id   INT UNSIGNED    NOT NULL,
    nivel_pct   DECIMAL(5,2)    NOT NULL COMMENT 'Percentagem 0-100',
    nivel_kg    DECIMAL(6,3)    NOT NULL COMMENT 'Quilogramas restantes',
    temperatura DECIMAL(5,2)    NULL     COMMENT 'ºC (opcional)',
    pressao_kpa DECIMAL(7,2)    NULL     COMMENT 'kPa (opcional)',
    lido_em     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sensor_id) REFERENCES sensores(id) ON DELETE CASCADE,
    INDEX idx_sensor_lido (sensor_id, lido_em)
) ENGINE=InnoDB;

-- Alertas gerados automaticamente
CREATE TABLE IF NOT EXISTS alertas (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sensor_id   INT UNSIGNED  NOT NULL,
    tipo        ENUM('critico','baixo','normal','cheio') NOT NULL,
    mensagem    TEXT          NOT NULL,
    nivel_pct   DECIMAL(5,2) NOT NULL,
    notificado  TINYINT(1)   NOT NULL DEFAULT 0,
    criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sensor_id) REFERENCES sensores(id) ON DELETE CASCADE,
    INDEX idx_sensor_notif (sensor_id, notificado)
) ENGINE=InnoDB;

-- Sensor de exemplo (dados de demonstração)
INSERT IGNORE INTO sensores (id, nome, localizacao) VALUES
    (1, 'Botijão Cozinha',  'Cozinha — armário inferior'),
    (2, 'Botijão Garagem',  'Garagem — zona de ferramentas'),
    (3, 'Botijão Exterior', 'Terraço — churrasqueira');

-- Leituras históricas de exemplo (últimas 24 h simuladas)
INSERT INTO leituras (sensor_id, nivel_pct, nivel_kg, temperatura, lido_em) VALUES
-- Sensor 1: a descer gradualmente
(1, 72.0, 9.360, 21.5, DATE_SUB(NOW(), INTERVAL 24 HOUR)),
(1, 68.0, 8.840, 21.8, DATE_SUB(NOW(), INTERVAL 20 HOUR)),
(1, 60.0, 7.800, 22.1, DATE_SUB(NOW(), INTERVAL 16 HOUR)),
(1, 48.5, 6.305, 22.0, DATE_SUB(NOW(), INTERVAL 12 HOUR)),
(1, 35.0, 4.550, 21.6, DATE_SUB(NOW(), INTERVAL  8 HOUR)),
(1, 28.0, 3.640, 21.2, DATE_SUB(NOW(), INTERVAL  4 HOUR)),
(1, 18.0, 2.340, 20.9, DATE_SUB(NOW(), INTERVAL  2 HOUR)),
(1, 12.5, 1.625, 20.7, NOW()),
-- Sensor 2: estável
(2, 85.0, 11.050, 19.5, DATE_SUB(NOW(), INTERVAL 12 HOUR)),
(2, 83.0, 10.790, 19.8, NOW()),
-- Sensor 3: nível baixo
(3, 22.0, 2.860, 18.0, DATE_SUB(NOW(), INTERVAL  6 HOUR)),
(3, 14.0, 1.820, 17.5, NOW());
